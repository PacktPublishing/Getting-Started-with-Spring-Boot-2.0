//video-7_1_start
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section7Application {

	public static void main(String[] args) {
		SpringApplication.run(Section7Application.class, args);
	}

}

//video-7_1_end